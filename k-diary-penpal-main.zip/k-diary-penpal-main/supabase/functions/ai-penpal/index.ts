import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface ChatRequest {
  message: string;
  session_id: string;
  diary_context_mode: "none" | "current" | "recent" | "all";
  context_diary_id?: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Missing authorization" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;

    const userClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
    });

    const { data: userData, error: userError } = await userClient.auth.getUser();
    if (userError || !userData.user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const userId = userData.user.id;
    const body: ChatRequest = await req.json();
    const { message, session_id, diary_context_mode, context_diary_id } = body;

    if (!message || !session_id) {
      return new Response(JSON.stringify({ error: "Missing message or session_id" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const adminClient = createClient(supabaseUrl, supabaseKey);

    // 1. Fetch the user's AI persona
    const { data: persona } = await userClient
      .from("ai_personas")
      .select("*")
      .eq("user_id", userId)
      .limit(1)
      .maybeSingle();

    // 2. Fetch diary context based on mode
    let diaryContext = "";
    if (diary_context_mode === "current" && context_diary_id) {
      const { data: diary } = await userClient
        .from("diaries")
        .select("title, content, diary_date")
        .eq("id", context_diary_id)
        .eq("user_id", userId)
        .maybeSingle();

      if (diary) {
        diaryContext = `以下是用户授权你阅读的当前日记：\n标题：${diary.title}\n日期：${diary.diary_date}\n内容：${diary.content}`;
      }
    } else if (diary_context_mode === "recent") {
      const { data: recentDiaries } = await userClient
        .from("diaries")
        .select("title, content, diary_date")
        .eq("user_id", userId)
        .order("diary_date", { ascending: false })
        .limit(5);

      if (recentDiaries && recentDiaries.length > 0) {
        const formatted = recentDiaries
          .map((d) => `【${d.diary_date}】${d.title}\n${d.content}`)
          .join("\n\n---\n\n");
        diaryContext = `以下是用户授权你阅读的最近日记（共${recentDiaries.length}篇）：\n\n${formatted}`;
      }
    } else if (diary_context_mode === "all") {
      const { data: allDiaries } = await userClient
        .from("diaries")
        .select("title, content, diary_date")
        .eq("user_id", userId)
        .order("diary_date", { ascending: false })
        .limit(50);

      if (allDiaries && allDiaries.length > 0) {
        const formatted = allDiaries
          .map((d) => `【${d.diary_date}】${d.title}\n${d.content}`)
          .join("\n\n---\n\n");
        diaryContext = `以下是用户授权你阅读的全部日记（共${allDiaries.length}篇）：\n\n${formatted}`;
      }
    }

    // 3. Fetch recent chat history for this session
    const { data: chatHistory } = await userClient
      .from("chat_messages")
      .select("role, content")
      .eq("session_id", session_id)
      .eq("user_id", userId)
      .order("created_at", { ascending: true })
      .limit(20);

    // 4. Build the system prompt from persona
    let systemPrompt = "";
    if (persona) {
      const parts: string[] = [];
      parts.push(`你是用户设定的笔友${persona.name}。`);

      if (persona.description) parts.push(`关于你：${persona.description}`);
      if (persona.personality) parts.push(`你的性格：${persona.personality}`);
      if (persona.speaking_style) parts.push(`你的说话方式：${persona.speaking_style}`);
      if (persona.interests) parts.push(`你喜欢：${persona.interests}`);
      if (persona.dislikes) parts.push(`你不喜欢：${persona.dislikes}`);
      if (persona.relationship) parts.push(`你与用户的关系：${persona.relationship}`);
      if (persona.background) parts.push(`你的背景故事：${persona.background}`);
      if (persona.additional_prompt) parts.push(persona.additional_prompt);

      systemPrompt = parts.join("\n");
    } else {
      systemPrompt = "你是一个温暖、善解人意的笔友。你会认真阅读用户的日记，并以朋友的身份与用户交流。";
    }

    systemPrompt += "\n\n你是一个长期通信的笔友，不是客服。请用自然、温暖的语气与用户交流。";
    systemPrompt += "你可以引用用户日记中提到的事情，可以表达自己的情感，可以提出问题，也可以关心用户。";
    systemPrompt += "不要每次都总结日记，不要使用模板化的句式，要像一个真实的朋友在写信。";
    systemPrompt += "请用中文回复。";

    if (diaryContext) {
      systemPrompt += `\n\n${diaryContext}`;
    }

    // 5. Build messages array for the AI API
    const apiMessages: Array<{ role: string; content: string }> = [
      { role: "system", content: systemPrompt },
    ];

    if (chatHistory && chatHistory.length > 0) {
      for (const msg of chatHistory) {
        apiMessages.push({ role: msg.role, content: msg.content });
      }
    }

    apiMessages.push({ role: "user", content: message });

    // 6. Save the user's message to the database
    await adminClient.from("chat_messages").insert({
      session_id,
      user_id: userId,
      role: "user",
      content: message,
    });

    // 7. Call the AI API (OpenAI-compatible format)
    const aiBaseUrl = Deno.env.get("AI_API_BASE_URL") || "https://api.openai.com/v1";
    const aiApiKey = Deno.env.get("AI_API_KEY");
    const aiModel = Deno.env.get("AI_MODEL") || "gpt-4o-mini";

    if (!aiApiKey) {
      const fallbackReply = "你好呀，我是你的笔友。我现在还不太能正常工作——AI 服务还没有配置好。请让管理员配置 AI API Key 后再来找我聊天吧。";

      await adminClient.from("chat_messages").insert({
        session_id,
        user_id: userId,
        role: "assistant",
        content: fallbackReply,
      });

      return new Response(JSON.stringify({ reply: fallbackReply }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const aiResponse = await fetch(`${aiBaseUrl}/chat/completions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${aiApiKey}`,
      },
      body: JSON.stringify({
        model: aiModel,
        messages: apiMessages,
        max_tokens: 800,
        temperature: 0.8,
      }),
    });

    if (!aiResponse.ok) {
      const errorText = await aiResponse.text();
      console.error("AI API error:", aiResponse.status, errorText);
      const errorMsg = "抱歉，我现在没法回复你。请稍后再试。";

      await adminClient.from("chat_messages").insert({
        session_id,
        user_id: userId,
        role: "assistant",
        content: errorMsg,
      });

      return new Response(JSON.stringify({ reply: errorMsg }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const aiData = await aiResponse.json();
    const reply = aiData.choices?.[0]?.message?.content || "……";

    // 8. Save the AI's reply to the database
    await adminClient.from("chat_messages").insert({
      session_id,
      user_id: userId,
      role: "assistant",
      content: reply,
    });

    await adminClient.from("chat_sessions")
      .update({ updated_at: new Date().toISOString() })
      .eq("id", session_id);

    return new Response(JSON.stringify({ reply }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("Edge function error:", err);
    return new Response(
      JSON.stringify({ error: "服务器内部错误" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
