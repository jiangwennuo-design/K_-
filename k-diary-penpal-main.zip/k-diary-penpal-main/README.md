# K 日记本 / 日记笔友

这是从单一源码 TXT 还原的 Vite + React + TypeScript 项目。账号、日记和聊天数据使用 Supabase；AI 笔友通过 Supabase Edge Function 调用一个 OpenAI 兼容接口。

## 最少需要哪些配置

只想登录、注册、写日记时，只需要一个 Supabase 项目中的两个前端公开值：

- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`

不需要申请任何 AI API，也不需要 Discord。Discord 登录默认关闭。

只有启用“和笔友聊天”时，才需要在 Supabase Edge Function 后端设置一个 `AI_API_KEY`。`SUPABASE_URL`、`SUPABASE_ANON_KEY` 和 `SUPABASE_SERVICE_ROLE_KEY` 由 Supabase Edge Function 运行环境提供，不要复制到前端 `.env`。

## 本地启动

```powershell
Copy-Item .env.example .env
# 编辑 .env，填入 Supabase URL 和 anon key
npm install
npm run dev
```

## 首次配置 Supabase

1. 在 Supabase Dashboard 的 SQL Editor 执行 `supabase/migrations/20260916000000_initial_schema.sql`。
2. 在 Authentication > URL Configuration 中：
   - `Site URL` 填真实网站地址；
   - `Redirect URLs` 加入真实网站地址和本地地址，例如 `http://localhost:5173/**`。
3. 在 Authentication > Providers 中确认 Email 已启用。
4. 将 Project Settings > API 中的 Project URL 和 anon/public key 写入本地 `.env` 或部署平台的环境变量。

邮箱密码登录成功后，应用会根据 Supabase session 自动从 `#/login` 跳到 `#/` 日记首页。

## 可选：Discord 登录

只有确定需要 Discord 时才申请 Discord OAuth：

1. 在 Supabase Authentication > Providers > Discord 中配置 Discord client ID/secret。
2. 按 Supabase 页面给出的 callback URL 配置 Discord 应用。
3. 将前端环境变量 `VITE_ENABLE_DISCORD_LOGIN=true`。

不开启时，登录页不会显示 Discord 按钮，也不影响邮箱登录。

## 可选：AI 笔友

部署 Edge Function 并设置密钥：

```powershell
supabase functions deploy ai-penpal
supabase secrets set AI_API_KEY=你的密钥
supabase secrets set AI_API_BASE_URL=https://api.openai.com/v1
supabase secrets set AI_MODEL=gpt-4o-mini
```

`AI_API_BASE_URL` 可换成任何兼容 OpenAI `/chat/completions` 的服务。未配置 `AI_API_KEY` 时，账号和日记仍可正常使用，聊天页会收到“AI 服务还没有配置好”的提示。

## 验证命令

```powershell
npm run typecheck
npm run lint
npm run build
```

## 安全提醒

- `.env` 已被 `.gitignore` 排除，不要把真实密钥打进 ZIP 或提交到仓库。
- 前端只能使用 anon/public key；绝不能使用 service role key。
- AI key 只放在 Supabase secrets 中。
